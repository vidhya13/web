<!DOCTYPE html>
<html>
<head>
<script>
window.alert = function() {
    debugger;
}
</script>
<title>Ably Shop A Ecommerce Category Flat Bootstrap Responsive Website| Checkout</title>
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<!--theme-style-->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shopin Responsive web template, Bootstrap Web Templates, Flat Web Templates, AndroId Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--theme-style-->
<link href="../css/style4.css" rel="stylesheet" type="text/css" media="all" />	
<script language="Javascript" src="jquery.js"></script>
<script type="text/JavaScript" src='state.js'></script>
<!--//theme-style-->
<script src="../js/jquery.min.js"></script>
 <link rel="stylesheet" type="text/css" href="style.css">
<!--- start-rate---->
<style>
.c
{
color:red;
}
</style>
</head>

<body>
<!--header-->

<div class="header">
	<div class="container">
		<div class="head">
			<div class=" logo">
				<a style="color:orange;font-size:20px;" href="../index.php">AblyShop</a>
			</div>
		</div>
	</div>
	<div class="header-top">
		<div class="container">
			<div class="col-sm-5 col-md-offset-2  header-login">
				<ul >
					<li><a href="../login.php">Login</a></li>
					<li><a href="../register.php">Register</a></li>
					<li><a href="../checkout.php">Checkout</a></li>
				</ul>
			</div>

			<div class="col-sm-5 header-social">
				<ul >
					<li><a href="#"><i></i></a></li>
					<li><a href="#"><i class="ic1"></i></a></li>
					<li><a href="#"><i class="ic2"></i></a></li>
					<li><a href="#"><i class="ic3"></i></a></li>
					<li><a href="#"><i class="ic4"></i></a></li>
				</ul>

			</div>
			<div class="clearfix"> </div>
		</div>
	</div>

	<div class="container">

		<div class="head-top">

			<div class="col-sm-100 col-md-offset-1">
				<nav class="navbar nav_bottom" role="navigation">

					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header nav_2">
						<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>

					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
						<ul class="nav navbar-nav nav_1">
							<li><a class="color" href="../index.php">Home</a></li>

							<li class="dropdown mega-dropdown active">
								<a class="color1" href="#" class="dropdown-toggle" data-toggle="dropdown">Accessories<span class="caret"></span></a>
								<div class="dropdown-menu ">
									<div class="menu-top">
										<div class="col1">
											<div class="h_nav">
												<h4>Watches</h4>
												<ul>
													<li><a href="../product.php">Accessories</a></li>
													<li><a href="../product.php">Bags</a></li>
													<li><a href="../product.php">Caps & Hats</a></li>
													<li><a href="../product.php">Hoodies & Sweatshirts</a></li>

												</ul>
											</div>
										</div>
										<div class="col1">
											<div class="h_nav">
												<h4>Cosmetics</h4>
												<ul>
													<li><a href="../product.php">Jackets & Coats</a></li>
													<li><a href="../product.php">Jeans</a></li>
													<li><a href="../product.php">Jewellery</a></li>
													<li><a href="../product.php">Jumpers & Cardigans</a></li>
													<li><a href="../product.php">Leather Jackets</a></li>
													<li><a href="../product.php">Long Sleeve T-Shirts</a></li>
												</ul>
											</div>
										</div>
										<div class="col1">
											<div class="h_nav">
												<h4>Handbags</h4>
												<ul>
													<li><a href="../product.php">Shirts</a></li>
													<li><a href="../product.php">Shoes, Boots & Trainers</a></li>
													<li><a href="../product.php">Sunglasses</a></li>
													<li><a href="../product.php">Sweatpants</a></li>
													<li><a href="../product.php">Swimwear</a></li>
													<li><a href="../product.php">Trousers & Chinos</a></li>

												</ul>

											</div>
										</div>
										<div class="col1">
											<div class="h_nav">
												<h4>Jewellery</h4>
												<ul>
													<li><a href="../product.php">T-Shirts</a></li>
													<li><a href="../product.php">Underwear & Socks</a></li>
													<li><a href="../product.php">Vests</a></li>
													<li><a href="../product.php">Jackets & Coats</a></li>
													<li><a href="../product.php">Jeans</a></li>
													<li><a href="../product.php">Jewellery</a></li>
												</ul>
											</div>
										</div>
										<div class="col1 col5">
											<img src="../images/me.png" class="img-responsive" alt="">
										</div>
										<div class="clearfix"></div>
									</div>
								</div>
							</li>
							<li class="dropdown mega-dropdown active">
								<a class="color2" href="#" class="dropdown-toggle" data-toggle="dropdown">Natural Oil's<span class="caret"></span></a>
								<div class="dropdown-menu mega-dropdown-menu">
									<div class="menu-top">
										<div class="col1">
											<div class="h_nav" width="100px">
												<h4>Natural Oil's</h4>
												<ul>
													<li><a href="../coconut_oil.php">Organic Wood Pressed Coconut Oil</a></li>
													<li><a href="../sesame_oil.php">Organic Wood Pressed Sesame Oil</a></li>
													<li><a href="../ground_oil.php">Organic Wood Pressed Groundnut Oil</a></li>


												</ul>
											</div>
										</div>

									</div>
								</div></li>
							<li class="dropdown mega-dropdown active">
								<a class="color2" href="#" class="dropdown-toggle" data-toggle="dropdown">Agriculture Power Tools<span class="caret"></span></a>
								<div class="dropdown-menu mega-dropdown-menu">
									<div class="menu-top">
										<div class="col1">
											<div class="h_nav" width="100px">
												<h4>Agriculture Power Tools</h4>
												<ul>
													<li><a href="../power_tools.php">Cultivator / Weeder</a></li>

												</ul>
											</div>
										</div>

									</div>
								</div></li>
							<li class="dropdown mega-dropdown active">
								<a class="color2" href="#" class="dropdown-toggle" data-toggle="dropdown">Appliances<span class="caret"></span></a>
								<div class="dropdown-menu mega-dropdown-menu">
									<div class="menu-top">
										<div class="col1">
											<div class="h_nav">
												<h4>Home</h4>
												<ul>
													<li><a href="../product.php">Accessories</a></li>
													<li><a href="../product.php">Bags</a></li>
													<li><a href="../product.php">Caps & Hats</a></li>
													<li><a href="../product.php">Hoodies & Sweatshirts</a></li>

												</ul>
											</div>
										</div>
										<div class="col1">
											<div class="h_nav">
												<h4>Electronics</h4>
												<ul>
													<li><a href="../product.php">Jackets & Coats</a></li>
													<li><a href="../product.php">Jeans</a></li>
													<li><a href="../product.php">Jewellery</a></li>
													<li><a href="../product.php">Jumpers & Cardigans</a></li>
													<li><a href="../product.php">Leather Jackets</a></li>
													<li><a href="../product.php">Long Sleeve T-Shirts</a></li>
												</ul>
											</div>
										</div>
										<div class="col1">
											<div class="h_nav">
												<h4>Digital</h4>

												<ul>
													<li><a href="../product.php">Shirts</a></li>
													<li><a href="../product.php">Shoes, Boots & Trainers</a></li>
													<li><a href="../product.php">Sunglasses</a></li>
													<li><a href="../product.php">Sweatpants</a></li>
													<li><a href="../product.php">Swimwear</a></li>
													<li><a href="../product.php">Trousers & Chinos</a></li>

												</ul>

											</div>
										</div>
										<div class="col1">
											<div class="h_nav">
												<h4>Pest Control</h4>
												<ul>
													<li><a href="../product.php">T-Shirts</a></li>
													<li><a href="../product.php">Underwear & Socks</a></li>
													<li><a href="../product.php">Vests</a></li>
													<li><a href="../product.php">Jackets & Coats</a></li>
													<li><a href="../product.php">Jeans</a></li>
													<li><a href="../product.php">Jewellery</a></li>
												</ul>
											</div>
										</div>
										<div class="col1 col5">
											<img src="../images/me1.png" class="img-responsive" alt="">
										</div>
										<div class="clearfix"></div>
									</div>
								</div>
							</li>
							<li class="dropdown mega-dropdown active">
								<a class="color2" href="#" class="dropdown-toggle" data-toggle="dropdown">Clothing<span class="caret"></span></a>
								<div class="dropdown-menu mega-dropdown-menu">
									<div class="menu-top">
										<div class="col1">
											<div class="h_nav">
												<h4>Men</h4>
												<ul>
													<li><a href="../product.php">Accessories</a></li>
													<li><a href="../product.php">Bags</a></li>
													<li><a href="../product.php">Caps & Hats</a></li>
													<li><a href="../product.php">Hoodies & Sweatshirts</a></li>

												</ul>
											</div>
										</div>
										<div class="col1">
											<div class="h_nav">
												<h4>Women</h4>
												<ul>
													<li><a href="../product.php">Jackets & Coats</a></li>
													<li><a href="../product.php">Jeans</a></li>
													<li><a href="../product.php">Jewellery</a></li>
													<li><a href="../product.php">Jumpers & Cardigans</a></li>
													<li><a href="../product.php">Leather Jackets</a></li>
													<li><a href="../product.php">Long Sleeve T-Shirts</a></li>
												</ul>
											</div>
										</div>
										<div class="col1">
											<div class="h_nav">
												<h4>Kids</h4>

												<ul>
													<li><a href="../product.php">Shirts</a></li>
													<li><a href="../product.php">Shoes, Boots & Trainers</a></li>
													<li><a href="../product.php">Sunglasses</a></li>
													<li><a href="../product.php">Sweatpants</a></li>
													<li><a href="../product.php">Swimwear</a></li>
													<li><a href="../product.php">Trousers & Chinos</a></li>

												</ul>

											</div>
										</div></li>

			
            <li ><a class="color6" target="_blank" href="http://ablywall.com/feedback.php ">Contact</a></li>
        </ul>
     </div><!-- /.navbar-collapse -->

</nav>

			</div>
			<div>
				<ul class="heart">
				<li>
				<a href="../wishlist.php" >
				<span class="glyphicon glyphicon-heart" aria-hidden="true"></span>
				</a></li>
				<li><a class="play-icon popup-with-zoom-anim" href="#small-dialog"><i class="glyphicon glyphicon-search"> </i></a></li>
					</ul>
					<div class="cart box_1">
						<a href="../checkout.php">
						<h3> <div class="total">
							<span name="sct" class="simpleCart_total" id="sc"></span></div>
							<img src="../images/cart.png" alt=""/></h3>
						</a>
						<p><a href="javascript:;" class="simpleCart_empty">Empty Cart</a></p>

					</div>
					<div class="clearfix"> </div>
					
						<!----->

						<!---pop-up-box		  
			<link href="../ss/popuo-box.css" rel="stylesheet" type="text/css" media="all"/> ---->			
			<script src="../js/jquery.magnific-popup.js" type="text/javascript"></script>
			<!---//pop-up-box---->
			<!--<div id="small-dialog" class="mfp-hide">
				<div class="search-top">
					<div class="login-search">
						<input type="submit" value="">
						<input type="text" value="Search.." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search..';}">		
					</div>
					<p>Ably shop</p>
				</div>			
			</div>  -->	
		 <script>
			$(document).ready(function() {
			$('.popup-with-zoom-anim').magnificPopup({
			type: 'inline',
			fixedContentPos: false,
			fixedBgPos: true,
			overflowY: 'auto',
			closeBtnInside: true,
			preloader: false,
			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-zoom-in'
			});
																						
			});
		</script>
						<!----->
			</div>
			<div class="clearfix"></div>
		</div>	
	</div>	
</div>
<!--banner-->
<div class="banner-top">
	<div class="container">
		<h1>Checkout</h1>
		<em></em>
		<h2><a href="../index.php">Home</a><label>/</label>Checkout</a></h2>
	</div>
</div>
<!--login-->
	<script>$(document).ready(function(c) {
					$('.close1').on('click', function(c){
						$('.cart-header').fadeOut('slow', function(c){
							$('.cart-header').remove();
						});
						});	  
					});
			   </script>
<script>$(document).ready(function(c) {
					$('.close2').on('click', function(c){
						$('.cart-header1').fadeOut('slow', function(c){
							$('.cart-header1').remove();
						});
						});	  
					});
			   </script>
			   <script>$(document).ready(function(c) {
					$('.close3').on('click', function(c){
						$('.cart-header2').fadeOut('slow', function(c){
							$('.cart-header2').remove();
						});
						});	  
					});
			   </script>

<?php
// Merchant key here as provided by Payu
$MERCHANT_KEY = "k0vIDvoO";

// Merchant Salt as provided by Payu
$SALT = "tjjGJx1GjP";

// End point - change to https://secure.payu.in for LIVE mode
$PAYU_BASE_URL = "https://secure.payu.in";

$action = "";

$posted = array();
if(isset($_GET['amount']))
	{
	$id=$_GET['amount'];

	$str='<span>&#8377;</span>';
	
	$coid=preg_replace("/[^0-9\.]/", "",$id);
	
	$posted['amount']=$coid;
	$posted['surl']="http://localhost/web/payu/success.php";
	$posted['furl']="http://localhost/web/payu/failure.php";
	$posted['productinfo']="abc";
	
if(!empty($_POST)) {
    //print_r($_POST);
  foreach($_POST as $key => $value) {    
    $posted[$key] = $value; 
	
  }
}

$formError = 0;

if(empty($posted['txnid'])) {
  // Generate random transaction id
  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
} else {
  $txnid = $posted['txnid'];
}
$hash = '';
// Hash Sequence
$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
if(empty($posted['hash']) && sizeof($posted) > 0) {
  if(
          empty($posted['key'])
          || empty($posted['txnid'])
          || empty($posted['amount'])
          || empty($posted['firstname'])
          || empty($posted['email'])
          || empty($posted['phone'])
          || empty($posted['productinfo'])
          || empty($posted['surl'])
          || empty($posted['furl'])
		  || empty($posted['service_provider'])
  ) {
    $formError = 1;
  } else {
    //$posted['productinfo'] = json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));
	$hashVarsSeq = explode('|', $hashSequence);
    $hash_string = '';
	
	foreach($hashVarsSeq as $hash_var) {
      $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
      $hash_string .= '|';
    }

    $hash_string .= $SALT;


    $hash = strtolower(hash('sha512', $hash_string));
    $action = $PAYU_BASE_URL . '/_payment';
  }
} elseif(!empty($posted['hash'])) {
  $hash = $posted['hash'];
  $action = $PAYU_BASE_URL . '/_payment';
}
?>
<html>
  <head>
  <script>
    var hash = '<?php echo $hash ?>';
    function submitPayuForm() {
      if(hash == '') {
        return;
      }
      var payuForm = document.forms.payuForm;
      payuForm.submit();
    }
  </script>
  </head>
  <body onload="submitPayuForm()">
  <div style="margin:50px">
	  <div class='resp_code frms'>
    <h2>Make your payment</h2>
    <br/>
    <?php if($formError) { ?>
	
      <span style="color:red">Please fill all mandatory fields.</span>
      <br/>
      <br/>
    <?php } ?>
    <form action="<?php echo $action; ?>" method="post" name="payuForm">
      <input type="hidden" name="key" value="<?php echo $MERCHANT_KEY ?>" />
      <input type="hidden" name="hash" value="<?php echo $hash ?>"/>
      <input type="hidden" name="txnid" value="<?php echo $txnid ?>" />
      <table>
      
        <tr>
          <td>Amount </td>
          <td><input name="amount" value="<?php echo (empty($posted['amount'])) ? '' : $posted['amount'] ?>" readonly/></td>
          
        </tr>
        <tr>
		<td><span class="c">*</span> First Name </td>
          <td><input name="firstname" id="firstname" value="<?php echo (empty($posted['firstname'])) ? '' : $posted['firstname']; ?>" /></td>
		<td><span class="c">*</span> Last Name </td>
          <td><input name="lastname" id="lastname" value="<?php echo (empty($posted['lastname'])) ? '' : $posted['lastname']; ?>" /></td>
          
         
        </tr>
        <tr>
		<td><span class="c">*</span> Email </td>
          <td><input name="email" id="email" value="<?php echo (empty($posted['email'])) ? '' : $posted['email']; ?>" /></td>
           <td><span class="c">*</span> Mobile Number </td>
          <td><input name="phone" value="<?php echo (empty($posted['phone'])) ? '' : $posted['phone']; ?>" /></td>
		  
		
          <td colspan="3"><textarea name="productinfo" hidden><?php echo (empty($posted['productinfo'])) ? '' : $posted['productinfo'] ?></textarea></td>
        </tr>
		 <tr>
		<td><span class="c">*</span> Address Line1 </td>
          <td><input name="add1" id="add1" value="<?php echo (empty($posted['add1'])) ? '' : $posted['add1']; ?>" /></td>
           <td><span class="c">*</span> Address Line2 </td>
          <td><input name="add2" id="add2" value="<?php echo (empty($posted['add2'])) ? '' : $posted['add2']; ?>" /></td>
		  
		
        
        </tr>
        <tr>
		<td><span class="c">*</span> State </td>
		   <td><select name="city" class="col-md-6"  id="listBox" onchange='selct_district(this.value)' value="<?php echo (empty($posted['State'])) ? '' : $posted['State']; ?>" >
		   <option>Tamilnadu</option>
		   <option>Karnataka</option>
		   <option>Kerala</option>
		   </select></td>
          <td><span class="c">*</span> City </td>
		   <td><select name="city" class="col-md-6" id='secondlist' value="<?php echo (empty($posted['city'])) ? '' : $posted['city']; ?>" >

		   </select></td>
		   
          <td colspan="3"><input name="surl" value="<?php echo (empty($posted['surl'])) ? '' : $posted['surl'] ?>" size="64" hidden/></td>
        </tr>
        <tr>
         <td><span class="c">*</span> Pincode </td>
		   <td><input name="city" value="<?php echo (empty($posted['city'])) ? '' : $posted['city']; ?>" /></td>
		   <td><span class="c">*</span> Country </td>
		   <td><select name="city" class="col-md-6" value="<?php echo (empty($posted['country'])) ? '' : $posted['country']; ?>" >
		   <option value="India">India</option>
		   </select></td>
          <td colspan="3"><input name="furl" value="<?php echo (empty($posted['furl'])) ? '' : $posted['furl'] ?>" size="64" hidden/></td>
        </tr>

        <tr>
          <td colspan="3"><input type="hidden" name="service_provider" value="payu_paisa" size="64" /></td>
        </tr>

      <!--  <tr>
          <td><b>Optional Parameters</b></td>
        </tr>
        <tr>
          <td>Last Name: </td>
          <td><input name="lastname" id="lastname" value="<?php //echo (empty($posted['lastname'])) ? '' : $posted['lastname']; ?>" /></td>
          <td>Cancel URI: </td>
          <td><input name="curl" value="" /></td>
        </tr>
        <tr>
          <td>Address1: </td>
          <td><input name="address1" value="<?php //echo (empty($posted['address1'])) ? '' : $posted['address1']; ?>" /></td>
          <td>Address2: </td>
          <td><input name="address2" value="<?php //echo (empty($posted['address2'])) ? '' : $posted['address2']; ?>" /></td>
        </tr>
        <tr>
          <td>City: </td>
          <td><input name="city" value="<?php //echo (empty($posted['city'])) ? '' : $posted['city']; ?>" /></td>
          <td>State: </td>
          <td><input name="state" value="<?php //echo (empty($posted['state'])) ? '' : $posted['state']; ?>" /></td>
        </tr>
        <tr>
          <td>Country: </td>
          <td><input name="country" value="<?php //echo (empty($posted['country'])) ? '' : $posted['country']; ?>" /></td>
          <td>Zipcode: </td>
          <td><input name="zipcode" value="<?php //echo (empty($posted['zipcode'])) ? '' : $posted['zipcode']; ?>" /></td>
        </tr>
        <tr>
          <td>UDF1: </td>
          <td><input name="udf1" value="<?php //echo (empty($posted['udf1'])) ? '' : $posted['udf1']; ?>" /></td>
          <td>UDF2: </td>
          <td><input name="udf2" value="<?php //echo (empty($posted['udf2'])) ? '' : $posted['udf2']; ?>" /></td>
        </tr>
        <tr>
          <td>UDF3: </td>
          <td><input name="udf3" value="<?php //echo (empty($posted['udf3'])) ? '' : $posted['udf3']; ?>" /></td>
          <td>UDF4: </td>
          <td><input name="udf4" value="<?php //echo (empty($posted['udf4'])) ? '' : $posted['udf4']; ?>" /></td>
        </tr>
        <tr>
          <td>UDF5: </td>
          <td><input name="udf5" value="<?php //echo (empty($posted['udf5'])) ? '' : $posted['udf5']; ?>" /></td>
          <td>PG: </td>
          <td><input name="pg" value="<?php //echo (empty($posted['pg'])) ? '' : $posted['pg']; ?>" /></td>
        </tr> -->
        <tr> 
          <?php if(!$hash) { ?>
            <td colspan="4"><input type="submit" value="Submit" class="btn btn-primary btn-lg" style="margin-left:500px"
			/></td>
          <?php } ?>
        </tr>
      </table>
	  </div>
	  </div>
    </form>
  </body>
  <?php } ?>
</html>
