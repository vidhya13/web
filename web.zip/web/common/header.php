<html>
<head>
<title>Ably Shop A Ecommerce Category Flat Bootstrap Responsive Website| Checkout</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<!--theme-style-->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shopin Responsive web template, Bootstrap Web Templates, Flat Web Templates, AndroId Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--theme-style-->
<link href="css/style4.css" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<script src="js/jquery.min.js"></script>
<!--- start-rate---->
<script src="js/jstarbox.js"></script>
	<link rel="stylesheet" href="css/jstarbox.css" type="text/css" media="screen" charset="utf-8" />
		<script type="text/javascript">
			jQuery(function() {
			jQuery('.starbox').each(function() {
				var starbox = jQuery(this);
					starbox.starbox({
					average: starbox.attr('data-start-value'),
					changeable: starbox.hasClass('unchangeable') ? false : starbox.hasClass('clickonce') ? 'once' : true,
					ghosting: starbox.hasClass('ghosting'),
					autoUpdateAverage: starbox.hasClass('autoupdate'),
					buttons: starbox.hasClass('smooth') ? false : starbox.attr('data-button-count') || 5,
					stars: starbox.attr('data-star-count') || 5
					}).bind('starbox-value-changed', function(event, value) {
					if(starbox.hasClass('random')) {
					var val = Math.random();
					starbox.next().text(' '+val);
					return val;
					} 
				})
			});
		});
		</script>
<!---//End-rate---->
</head>
<body>
<!--header-->
<div class="header">
<div class="container">
		<div class="head">
			<div class=" logo">
				<a style="color:orange;font-size:20px;" href="index.php">AblyShop</a>	
			</div>
		</div>
	</div>
	<div class="header-top">
		<div class="container">
		<div class="col-sm-5 col-md-offset-2  header-login">
					<ul >
						<li><a href="login.php">Login</a></li>
						<li><a href="register.php">Register</a></li>
						<li><a href="checkout.php">Checkout</a></li>
					</ul>
				</div>
				
			<div class="col-sm-5 header-social">		
					<ul >
						<li><a href="#"><i></i></a></li>
						<li><a href="#"><i class="ic1"></i></a></li>
						<li><a href="#"><i class="ic2"></i></a></li>
						<li><a href="#"><i class="ic3"></i></a></li>
						<li><a href="#"><i class="ic4"></i></a></li>
					</ul>
					
			</div>
				<div class="clearfix"> </div>
		</div>
		</div>
		
		<div class="container">
		
			<div class="head-top">
			
		 <div class="col-sm-100 col-md-offset-1">
				<nav class="navbar nav_bottom" role="navigation">
 
 <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header nav_2">
      <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
   </div> 
   <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
        <ul class="nav navbar-nav nav_1">
            <li><a class="color" href="index.php">Home</a></li>
            
    		<li class="dropdown mega-dropdown active">
			    <a class="color1" href="#" class="dropdown-toggle" data-toggle="dropdown">Accessories<span class="caret"></span></a>				
				<div class="dropdown-menu ">
                    <div class="menu-top">
						<div class="col1">
							<div class="h_nav">
								<h4>Watches</h4>
									<ul>
										<li><a href="product.php">Accessories</a></li>
										<li><a href="product.php">Bags</a></li>
										<li><a href="product.php">Caps & Hats</a></li>
										<li><a href="product.php">Hoodies & Sweatshirts</a></li>
										
									</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Cosmetics</h4>
								<ul>
										<li><a href="product.php">Jackets & Coats</a></li>
										<li><a href="product.php">Jeans</a></li>
										<li><a href="product.php">Jewellery</a></li>
										<li><a href="product.php">Jumpers & Cardigans</a></li>
										<li><a href="product.php">Leather Jackets</a></li>
										<li><a href="product.php">Long Sleeve T-Shirts</a></li>
									</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Handbags</h4>
									<ul>
										<li><a href="product.php">Shirts</a></li>
										<li><a href="product.php">Shoes, Boots & Trainers</a></li>
										<li><a href="product.php">Sunglasses</a></li>
										<li><a href="product.php">Sweatpants</a></li>
										<li><a href="product.php">Swimwear</a></li>
										<li><a href="product.php">Trousers & Chinos</a></li>
										
									</ul>	
								
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Jewellery</h4>
								<ul>
									<li><a href="product.php">T-Shirts</a></li>
									<li><a href="product.php">Underwear & Socks</a></li>
									<li><a href="product.php">Vests</a></li>
									<li><a href="product.php">Jackets & Coats</a></li>
									<li><a href="product.php">Jeans</a></li>
									<li><a href="product.php">Jewellery</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1 col5">
						<img src="images/me.png" class="img-responsive" alt="">
						</div>
						<div class="clearfix"></div>
					</div>                  
				</div>				
			</li>
			<li class="dropdown mega-dropdown active">
			    <a class="color2" href="#" class="dropdown-toggle" data-toggle="dropdown">Natural Oil's<span class="caret"></span></a>
				<div class="dropdown-menu mega-dropdown-menu">
                    <div class="menu-top">
						<div class="col1">
							<div class="h_nav" width="100px">
								<h4>Natural Oil's</h4>
									<ul>
										<li><a href="coconut_oil.php">Organic Wood Pressed Coconut Oil</a></li>
										<li><a href="sesame_oil.php">Organic Wood Pressed Sesame Oil</a></li>
										<li><a href="ground_oil.php">Organic Wood Pressed Groundnut Oil</a></li>
										
										
									</ul>	
							</div>							
						</div>

						</div>
						</div></li>
			<li class="dropdown mega-dropdown active">
				<a class="color2" href="#" class="dropdown-toggle" data-toggle="dropdown">Agriculture Power Tools<span class="caret"></span></a>
				<div class="dropdown-menu mega-dropdown-menu">
					<div class="menu-top">
						<div class="col1">
							<div class="h_nav" width="100px">
								<h4>Agriculture Power Tools</h4>
								<ul>
									<li><a href="power_tools.php">Cultivator / Weeder</a></li>

								</ul>
							</div>
						</div>

					</div>
				</div></li>
			<li class="dropdown mega-dropdown active">
			    <a class="color2" href="#" class="dropdown-toggle" data-toggle="dropdown">Appliances<span class="caret"></span></a>				
				<div class="dropdown-menu mega-dropdown-menu">
                    <div class="menu-top">
						<div class="col1">
							<div class="h_nav">
								<h4>Home</h4>
									<ul>
										<li><a href="product.php">Accessories</a></li>
										<li><a href="product.php">Bags</a></li>
										<li><a href="product.php">Caps & Hats</a></li>
										<li><a href="product.php">Hoodies & Sweatshirts</a></li>
										
									</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Electronics</h4>
								<ul>
										<li><a href="product.php">Jackets & Coats</a></li>
										<li><a href="product.php">Jeans</a></li>
										<li><a href="product.php">Jewellery</a></li>
										<li><a href="product.php">Jumpers & Cardigans</a></li>
										<li><a href="product.php">Leather Jackets</a></li>
										<li><a href="product.php">Long Sleeve T-Shirts</a></li>
									</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Digital</h4>
								
<ul>
										<li><a href="product.php">Shirts</a></li>
										<li><a href="product.php">Shoes, Boots & Trainers</a></li>
										<li><a href="product.php">Sunglasses</a></li>
										<li><a href="product.php">Sweatpants</a></li>
										<li><a href="product.php">Swimwear</a></li>
										<li><a href="product.php">Trousers & Chinos</a></li>
										
									</ul>	
								
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Pest Control</h4>
								<ul>
									<li><a href="product.php">T-Shirts</a></li>
									<li><a href="product.php">Underwear & Socks</a></li>
									<li><a href="product.php">Vests</a></li>
									<li><a href="product.php">Jackets & Coats</a></li>
									<li><a href="product.php">Jeans</a></li>
									<li><a href="product.php">Jewellery</a></li>
								</ul>	
							</div>							
						</div>
						<div class="col1 col5">
						<img src="images/me1.png" class="img-responsive" alt="">
						</div>
						<div class="clearfix"></div>
					</div>                  
				</div>				
			</li>
			<li class="dropdown mega-dropdown active">
			    <a class="color2" href="#" class="dropdown-toggle" data-toggle="dropdown">Clothing<span class="caret"></span></a>				
				<div class="dropdown-menu mega-dropdown-menu">
                    <div class="menu-top">
						<div class="col1">
							<div class="h_nav">
								<h4>Men</h4>
									<ul>
										<li><a href="product.php">Accessories</a></li>
										<li><a href="product.php">Bags</a></li>
										<li><a href="product.php">Caps & Hats</a></li>
										<li><a href="product.php">Hoodies & Sweatshirts</a></li>
										
									</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Women</h4>
								<ul>
										<li><a href="product.php">Jackets & Coats</a></li>
										<li><a href="product.php">Jeans</a></li>
										<li><a href="product.php">Jewellery</a></li>
										<li><a href="product.php">Jumpers & Cardigans</a></li>
										<li><a href="product.php">Leather Jackets</a></li>
										<li><a href="product.php">Long Sleeve T-Shirts</a></li>
									</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Kids</h4>
								
<ul>
										<li><a href="product.php">Shirts</a></li>
										<li><a href="product.php">Shoes, Boots & Trainers</a></li>
										<li><a href="product.php">Sunglasses</a></li>
										<li><a href="product.php">Sweatpants</a></li>
										<li><a href="product.php">Swimwear</a></li>
										<li><a href="product.php">Trousers & Chinos</a></li>
										
									</ul>	
								
							</div>							
						</div></li>
			<!--			<li class="dropdown mega-dropdown active">
			    <a class="color2" href="#" class="dropdown-toggle" data-toggle="dropdown">Shoes & Footwear<span class="caret"></span></a>				
				<div class="dropdown-menu mega-dropdown-menu">
                    <div class="menu-top">
						<div class="col1">
							<div class="h_nav">
								<h4>Men</h4>
									<ul>
										<li><a href="product.php">Accessories</a></li>
										<li><a href="product.php">Bags</a></li>
										<li><a href="product.php">Caps & Hats</a></li>
										<li><a href="product.php">Hoodies & Sweatshirts</a></li>
										
									</ul>	
							</div>							
						</div>
						<div class="col1">
							<div class="h_nav">
								<h4>Women</h4>
								<ul>
										<li><a href="product.php">Jackets & Coats</a></li>
										<li><a href="product.php">Jeans</a></li>
										<li><a href="product.php">Jewellery</a></li>
										<li><a href="product.php">Jumpers & Cardigans</a></li>
										<li><a href="product.php">Leather Jackets</a></li>
										<li><a href="product.php">Long Sleeve T-Shirts</a></li>
									</ul>	
							</div>							
						</div>
								
						</div>
						</div></li>-->
						
		<!--	<li><a class="color3" href="product.php">Sale</a></li> -->
			
            <li ><a class="color6" target="_blank" href="http://ablywall.com/feedback.php">Contact</a></li>
        </ul>
     </div><!-- /.navbar-collapse -->

</nav>
			</div>
			<div class="">
				<ul class="heart">
				<li>
				<a href="wishlist.php" >
				<span class="glyphicon glyphicon-heart" aria-hidden="true"></span>
				</a></li>
				<li><a class="play-icon popup-with-zoom-anim" href="#small-dialog"><i class="glyphicon glyphicon-search"> </i></a></li>
					</ul>
					<div class="cart box_1">
						<a href="checkout.php">
						<h3> <div class="total" >
							<span class="simpleCart_total"></span></div>
							<img src="images/cart.png" alt=""/></h3>
						</a>
						<p><a href="javascript:;" class="simpleCart_empty">Empty Cart</a></p>

					</div>
					<div class="clearfix"> </div>
					</div>
			<div class="clearfix"></div>
		</div>	
	</div>	
</div>
	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
			<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
			<!---//pop-up-box---->
			<div id="small-dialog" class="mfp-hide">
				<div class="search-top">
					<div class="login-search">
						<input type="submit" value="">
						<input type="text" value="Search.." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search..';}">		
					</div>
					<p>Ably shop</p>
				</div>				
			</div>
		 <script>
			$(document).ready(function() {
			$('.popup-with-zoom-anim').magnificPopup({
			type: 'inline',
			fixedContentPos: false,
			fixedBgPos: true,
			overflowY: 'auto',
			closeBtnInside: true,
			preloader: false,
			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-zoom-in'
			});
																						
			});
		</script>
						<!----->
			</div>
			<div class="clearfix"></div>
		</div>	
	</div>	
</div>
					</body>
					</html>