

<?php include('common/header.php'); ?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<!--banner-->
<div class="banner-top">
	<div class="container">
		<h1>Wishlist</h1>
		<em></em>
		<h2><a href="index.php">Home</a><label>/</label>Wishlist</a></h2>
	</div>
</div>
<!--login-->
	<div class="container">
		<div class="wishlist">
			<h6><a href="#">Product Name</a>	<a href="#">Unit Price</a>	<a href="#">Stock Status</a></h6>	
			<p>No products were added to the wishlist</p>
		</div>
	</div>
<!--//login-->
<!--brand-->
	<?php include('common/footer.php'); ?>

</body>
</html>