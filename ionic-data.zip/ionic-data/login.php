<?php
	error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

    $postdata = file_get_contents("php://input");
    $request = json_decode($postdata);
   
    $email = $request->email;
    $pass = $request->password;
  
 // $email = "aa@gmail.com";
 // $pass ="aaa";

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ionic-data";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
	$sql = "";
	if(!empty($email)) {
	$sql = mysqli_query($conn,"select * from users where email='{$email}' and password='{$pass}'") ;

	}
if(mysqli_num_rows($sql)>0){
   echo "Add successfully\n";
}
else
{
echo "";
}